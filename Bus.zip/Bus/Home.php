<?php
include("Config.php");
?>
<!DOCTYPE html PUBLIC "-//W3C//DTD XHTML 1.0 Transitional//EN" "http://www.w3.org/TR/xhtml1/DTD/xhtml1-transitional.dtd">
<html xmlns="http://www.w3.org/1999/xhtml">
<head>
<meta http-equiv="Content-Type" content="text/html; charset=iso-8859-1" />
<title>Home</title>
<link rel="stylesheet" href="style.css">
<link rel="stylesheet" href="style1.css">
</head>
<body bgcolor="#CCCCCC">
<div>
<?php
include_once 'header.php';
?>
<ul>
<li><a href="Home.php">HOME</a></li>
                    <li><a href="signin.php">CANCEL TICKETS</a></li>
            <li><a href="signup.php">CREATE AN ACCOUNT</a></li>
            <li><a href="signin.php">ONLINE SIGN IN</a></li>
                <li>
           <a href="Admin/admin.php">ADMIN LOGIN</a>
		   </li>
		   <li>
		    <a href="staff/stafflogin.php">STAFF LOGIN</a>
        </li>
		 <li>
		    <a href="about.html">About Us</a>
        </li>
    </ul>
<marquee  behaviour="scroll" direction="left" scrollamount="4"> HANIF ENTERPRISE : </span>
                                    <span style="color: #000000;"></span>
                                                                            Dhaka->Dinajpur<span style="color:black;margin-right:5px;">,
																			</span>                                        Dhaka->Moulvibazar
																			<span style="color:black;margin-right:5px;">,</span>                                        Dhaka->Teknaf<span style="color:black;margin-right:5px;">,</span>                                        Narayanganj->Kurigram<span style="color:black;margin-right:5px;">,</span>                                        Dhaka->Meherpur<span style="color:black;margin-right:5px;">,</span>                                        Dhaka->Cox's Bazar<span style="color:black;margin-right:5px;">,</span>                                        Bandarban->Rajshahi<span style="color:black;margin-right:5px;">,</span>                                        Chittagong->Gazipur<span style="color:black;margin-right:5px;">,</span>                                        Dhaka->Rahanpur<span style="color:black;margin-right:5px;">,</span>                                        chandra->Chittagong<span style="color:black;margin-right:5px;">,</span>                                        Dhaka->Bandarban<span style="color:black;margin-right:5px;">,</span>                                        Narayanganj->Kolkata<span style="color:black;margin-right:5px;">,</span>                                        Narayanganj->Dinajpur<span style="color:black;margin-right:5px;">,</span>                                        Dhaka->HILI<span style="color:black;margin-right:5px;">,</span>                                        Dhaka->Kaptai<span style="color:black;margin-right:5px;">,</span>                                        Sayadabad->Kushtia<span style="color:black;margin-right:5px;">,</span>                                        Soilkupa->Dhaka<span style="color:black;margin-right:5px;">,</span>                                        Cox's Bazar->Dhaka<span style="color:black;margin-right:5px;">,</span>                                        Gazipur->Kaptai<span style="color:black;margin-right:5px;">,</span>                                        Dhaka->Naogaon<span style="color:black;margin-right:5px;">,</span>                                        Gazipur->Cox's Bazar<span style="color:black;margin-right:5px;">,</span>                                        Bandarban->Abdullahpur<span style="color:black;margin-right:5px;">,</span>                                        Narayanganj->Naogaon<span style="color:black;margin-right:5px;">,</span>                                        Bandarban->Dhaka<span style="color:black;margin-right:5px;">,</span>                                        Narayanganj->Soilkupa<span style="color:black;margin-right:5px;">,</span>                                        Dhaka->Fatikchari<span style="color:black;margin-right:5px;">,</span>                                        Dhaka->Sylhet<span style="color:black;margin-right:5px;">,</span>                                        Meherpur->Dhaka<span style="color:black;margin-right:5px;">,</span>                                        Dhaka->Chittagong<span style="color:black;margin-right:5px;">,</span>                                        Narayanganj->Sylhet<span style="color:black;margin-right:5px;">,</span>                                        Dhaka->Pabna<span style="color:black;margin-right:5px;">,</span>                                        Cox's Bazar->Rangpur<span style="color:black;margin-right:5px;">,</span>                                        Cox's Bazar->Gazipur<span style="color:black;margin-right:5px;">,</span>                                        Dhaka->Beanibazar<span style="color:black;margin-right:5px;">,</span>                                        Manikganj->Cox's Bazar<span style="color:black;margin-right:5px;">,</span>                                        Dhaka->Kolkata<span style="color:black;margin-right:5px;">,</span>                                        Dhaka->Dirai<span style="color:black;margin-right:5px;">,</span>                                        Narayanganj->Rajshahi<span style="color:black;margin-right:5px;">,</span>                                        Dhaka->Rangpur<span style="color:black;margin-right:5px;">,</span>                                        Dhaka->Rangamati<span style="color:black;margin-right:5px;">,</span>                                        Dhaka->Kansat<span style="color:black;margin-right:5px;">,</span>                                        Dhaka->Dinajpur<span style="color:black;margin-right:5px;">,</span>                                        Chittagong->Dhaka<span style="color:black;margin-right:5px;">,</span>                                        Dhaka->Jaipurhat<span style="color:black;margin-right:5px;">,</span>                                        Narayanganj->Cox's Bazar<span style="color:black;margin-right:5px;">,</span>                                        Dhaka->Akkelpur<span style="color:black;margin-right:5px;">,</span>                                        Cox's Bazar->Chapainababganj<span style="color:black;margin-right:5px;">,</span>                                        Dhaka->Gaibandha<span style="color:black;margin-right:5px;">,</span>                                        Dhaka->Sunamganj<span style="color:black;margin-right:5px;">,</span>                                        Cox's Bazar->Manikganj<span style="color:black;margin-right:5px;">,</span>                                        Chittagong->Kolkata<span style="color:black;margin-right:5px;">,</span>                                        Soilkupa->Narayanganj<span style="color:black;margin-right:5px;">,</span>                                        Dhaka->Soilkupa<span style="color:black;margin-right:5px;">,</span>                                        Cox's Bazar->Kushtia<span style="color:black;margin-right:5px;">,</span>                                        Gazipur->Chittagong<span style="color:black;margin-right:5px;">,</span>                                        Narayanganj->Rangpur<span style="color:black;margin-right:5px;">,</span>                                        Dhaka->Chapainababganj<span style="color:black;margin-right:5px;">,</span>                                        Dhaka->Bogra<span style="color:black;margin-right:5px;">,</span>                                        Narayanganj->Meherpur<span style="color:black;margin-right:5px;">,</span>                                        Chittagong->chandra<span style="color:black;margin-right:5px;">,</span>                                        Narayanganj->Chittagong                                                                <span style="color: #000000;">  |</marquee>
	
	<div>																		
<form target="_blank" method="post" action="show.php">
<label>Leave Form</label><br />
<select name="source" required >
    <option value="" label="---" selected="selected">---</option>
    <option value="Abullahpur" label="ABDULLAHPUR">ABDULLAHPUR</option>
    <option value="B-baria" label="B-BARIA">B-BARIA</option>
    <option value="Babuchar" label="BABUCHAR">BABUCHAR</option>
    <option value="Bagaihat" label="BAGAIHAT">BAGAIHAT</option>
    <option value="Bagerhat" label="BAGERHAT">BAGERHAT</option>
    <option value="Bandarban" label="BANDARBAN">BANDARBAN</option>
    <option value="Barguna" label="BARGUNA">BARGUNA</option>
    <option value="Barisal" label="BARISAL">BARISAL</option>
    <option value="Basurhat" label="BASURHAT">BASURHAT</option>
    <option value="Beanibazar" label="BEANIBAZAR">BEANIBAZAR</option>
    <option value="Benapole" label="BENAPOLE">BENAPOLE</option>
    <option value="Birampur" label="BIRAMPUR">BIRAMPUR</option>
    <option value="Bogra" label="BOGRA">BOGRA</option>
    <option value="Bonpara" label="BONPARA">BONPARA</option>
    <option value="Chandpur" label="CHANDPUR">CHANDPUR</option>
    <option value="Dhaka" label="CHANDRA">CHANDRA</option>
    <option value="Rajshahi" label="CHAPAINABABGANJ">CHAPAINABABGANJ</option>
    <option value="Chittagong" label="CHITTAGONG">CHITTAGONG</option>
    <option value="Comilla" label="COMILLA">COMILLA</option>
    <option value="Cox's bazar" label="COX'S BAZAR">COX'S BAZAR</option>
    <option value="Dhaka" label="DHAKA">DHAKA</option>
    <option value="Dinajpur" label="DINAJPUR">DINAJPUR</option>
    <option value="Kushtia" label="DORSHONA">DORSHONA</option>
    <option value="Faridpur" label="FARIDPUR">FARIDPUR</option>
    <option value="Feni" label="FENI">FENI</option>
    <option value="Fulbari" label="FULBARI">FULBARI</option>
    <option value="Gaibandha" label="GAIBANDHA">GAIBANDHA</option>
    <option value="Dhaka" label="GAZIPUR">GAZIPUR</option>
    <option value="Rajshahi" label="GODAGARI">GODAGARI</option>
    <option value="Faridpur" label="GOPALGANJ">GOPALGANJ</option>   
    <option value="Dinajpur" label="HILI">HILI</option>
    <option value="Bogura" label="JAIPURHAT">JAIPURHAT</option>
    <option value="Jessore" label="JESSORE">JESSORE</option>
    <option value="Jhenaidha" label="JHENAIDAH">JHENAIDAH</option>
    <option value="Jhenaidha" label="KALIGANJ">KALIGANJ</option>
    <option value="Rajshahi" label="KANSAT">KANSAT</option>
    <option value="Khagrachari" label="KHAGRACHARI">KHAGRACHARI</option>
    <option value="Khulna" label="KHULNA">KHULNA</option>
    <option value="Kuakata" label="KUAKATA">KUAKATA</option>
    <option value="Kurigram" label="KURIGRAM">KURIGRAM</option>
    <option value="Kushtia" label="KUSHTIA">KUSHTIA</option>
    <option value="Lakhipur" label="LAKHIPUR">LAKHIPUR</option>
    <option value="Lalmonirhat" label="LALMONIRHAT">LALMONIRHAT</option>
    <option value="Magura" label="MAGURA">MAGURA</option>
    <option value="Dhaka" label="MALIBAG">MALIBAG</option>
    <option value="Manikganj" label="MANIKGANJ">MANIKGANJ</option>
    <option value="Meherpur" label="MEHERPUR">MEHERPUR</option>
    <option value="Dhaka" label="MOHAKHALI">MOHAKHALI</option>
    <option value="Sylhet" label="MOULVIBAZAR">MOULVIBAZAR</option>
    <option value="Mymensing" label="MYMENSINGH">MYMENSINGH</option>
    <option value="Naogan" label="NAOGAON">NAOGAON</option>
    <option value="Narayanganj" label="NARAYANGANJ">NARAYANGANJ</option>
    <option value="Rajshahi" label="NATORE">NATORE</option>
    <option value="Noakhali" label="NOAKHALI">NOAKHALI</option>
    <option value="Narayanganj" label="NORDA">NORDA</option>
    <option value="Kushtia" label="PABNA">PABNA</option>
    <option value="Kushtia" label="PAKSHI">PAKSHI</option>
    <option value="Pirojpur" label="PIROJPUR">PIROJPUR</option>
    <option value="Rajshahi" label="PUTHIA">PUTHIA</option>
    <option value="Rajshahi" label="RAHANPUR">RAHANPUR</option>
    <option value="Faridpur" label="RAJABARI">RAJABARI</option>
    <option value="Rajshahi" label="RAJSHAHI">RAJSHAHI</option>
    <option value="Rangamati" label="RANGAMATI">RANGAMATI</option>
    <option value="Rangpur" label="RANGPUR">RANGPUR</option>
    <option value="Kushtia" label="RUPPUR">RUPPUR</option>
    <option value="Khulna" label="SATKHIRA">SATKHIRA</option>
    <option value="Narayngang" label="SAYADABAD">SAYADABAD</option>
    <option value="Dhaka" label="SHAHJADPUR">SHAHJADPUR</option>
    <option value="Sherpur" label="SHERPUR">SHERPUR</option>
    <option value="Sirajgonj" label="SIRAJGONJ">SIRAJGONJ</option>
    <option value="Syedpur" label="SYEDPUR">SYEDPUR</option>
    <option value="Sylhet" label="SYLHET">SYLHET</option>
    <option value="Tangail" label="TANGAIL">TANGAIL</option>
    <option value="Teknaf" label="TEKNAF">TEKNAF</option>
    <option value="Thakurgan" label="THAKURGAON">THAKURGAON</option>
    <option value="Dhaka" label="TONGI">TONGI</option>
    <option value="Foridpur" label="TUNGIPARA">TUNGIPARA</option>
    <option value="Dhaka" label="UTTARA">UTTARA</option> 
    <option value="Kushtia" label="VERAMARA">VERAMARA</option>
    <option value="Voirob" label="VOIROB">VOIROB</option>
</select><br />
<label>Going To</label><br />
<select name="desti" required>
    <option value="" label="---" selected="selected">---</option>
    <option value="Abullahpur" label="ABDULLAHPUR">ABDULLAHPUR</option>
    <option value="B-baria" label="B-BARIA">B-BARIA</option>
    <option value="Babuchar" label="BABUCHAR">BABUCHAR</option>
    <option value="Bagaihat" label="BAGAIHAT">BAGAIHAT</option>
    <option value="Bagerhat" label="BAGERHAT">BAGERHAT</option>
    <option value="Bandarban" label="BANDARBAN">BANDARBAN</option>
    <option value="Barguna" label="BARGUNA">BARGUNA</option>
    <option value="Barisal" label="BARISAL">BARISAL</option>
    <option value="Basurhat" label="BASURHAT">BASURHAT</option>
    <option value="Beanibazar" label="BEANIBAZAR">BEANIBAZAR</option>
    <option value="Benapole" label="BENAPOLE">BENAPOLE</option>
    <option value="Birampur" label="BIRAMPUR">BIRAMPUR</option>
    <option value="Bogra" label="BOGRA">BOGRA</option>
    <option value="Bonpara" label="BONPARA">BONPARA</option>
    <option value="Chandpur" label="CHANDPUR">CHANDPUR</option>
    <option value="Dhaka" label="CHANDRA">CHANDRA</option>
    <option value="Rajshahi" label="CHAPAINABABGANJ">CHAPAINABABGANJ</option>
    <option value="Chittagong" label="CHITTAGONG">CHITTAGONG</option>
    <option value="Comilla" label="COMILLA">COMILLA</option>
    <option value="Cox's bazar" label="COX'S BAZAR">COX'S BAZAR</option>
    <option value="Dhaka" label="DHAKA">DHAKA</option>
    <option value="Dinajpur" label="DINAJPUR">DINAJPUR</option>
    <option value="Kushtia" label="DORSHONA">DORSHONA</option>
    <option value="Faridpur" label="FARIDPUR">FARIDPUR</option>
    <option value="Feni" label="FENI">FENI</option>
    <option value="Fulbari" label="FULBARI">FULBARI</option>
    <option value="Gaibandha" label="GAIBANDHA">GAIBANDHA</option>
    <option value="Dhaka" label="GAZIPUR">GAZIPUR</option>
    <option value="Rajshahi" label="GODAGARI">GODAGARI</option>
    <option value="Faridpur" label="GOPALGANJ">GOPALGANJ</option>   
    <option value="Dinajpur" label="HILI">HILI</option>
    <option value="Bogura" label="JAIPURHAT">JAIPURHAT</option>
    <option value="Jessore" label="JESSORE">JESSORE</option>
    <option value="Jhenaidha" label="JHENAIDAH">JHENAIDAH</option>
    <option value="Jhenaidha" label="KALIGANJ">KALIGANJ</option>
    <option value="Rajshahi" label="KANSAT">KANSAT</option>
    <option value="Khagrachari" label="KHAGRACHARI">KHAGRACHARI</option>
    <option value="Khulna" label="KHULNA">KHULNA</option>
    <option value="Kuakata" label="KUAKATA">KUAKATA</option>
    <option value="Kurigram" label="KURIGRAM">KURIGRAM</option>
    <option value="Kushtia" label="KUSHTIA">KUSHTIA</option>
    <option value="Lakhipur" label="LAKHIPUR">LAKHIPUR</option>
    <option value="Lalmonirhat" label="LALMONIRHAT">LALMONIRHAT</option>
    <option value="Magura" label="MAGURA">MAGURA</option>
    <option value="Dhaka" label="MALIBAG">MALIBAG</option>
    <option value="Manikganj" label="MANIKGANJ">MANIKGANJ</option>
    <option value="Meherpur" label="MEHERPUR">MEHERPUR</option>
    <option value="Dhaka" label="MOHAKHALI">MOHAKHALI</option>
    <option value="Sylhet" label="MOULVIBAZAR">MOULVIBAZAR</option>
    <option value="Mymensing" label="MYMENSINGH">MYMENSINGH</option>
    <option value="Naogan" label="NAOGAON">NAOGAON</option>
    <option value="Narayanganj" label="NARAYANGANJ">NARAYANGANJ</option>
    <option value="Rajshahi" label="NATORE">NATORE</option>
    <option value="Noakhali" label="NOAKHALI">NOAKHALI</option>
    <option value="Narayanganj" label="NORDA">NORDA</option>
    <option value="Kushtia" label="PABNA">PABNA</option>
    <option value="Kushtia" label="PAKSHI">PAKSHI</option>
    <option value="Pirojpur" label="PIROJPUR">PIROJPUR</option>
    <option value="Rajshahi" label="PUTHIA">PUTHIA</option>
    <option value="Rajshahi" label="RAHANPUR">RAHANPUR</option>
    <option value="Faridpur" label="RAJABARI">RAJABARI</option>
    <option value="Rajshahi" label="RAJSHAHI">RAJSHAHI</option>
    <option value="Rangamati" label="RANGAMATI">RANGAMATI</option>
    <option value="Rangpur" label="RANGPUR">RANGPUR</option>
    <option value="Kushtia" label="RUPPUR">RUPPUR</option>
    <option value="Khulna" label="SATKHIRA">SATKHIRA</option>
    <option value="Narayngang" label="SAYADABAD">SAYADABAD</option>
    <option value="Dhaka" label="SHAHJADPUR">SHAHJADPUR</option>
    <option value="Sherpur" label="SHERPUR">SHERPUR</option>
    <option value="Sirajgonj" label="SIRAJGONJ">SIRAJGONJ</option>
    <option value="Syedpur" label="SYEDPUR">SYEDPUR</option>
    <option value="Sylhet" label="SYLHET">SYLHET</option>
    <option value="Tangail" label="TANGAIL">TANGAIL</option>
    <option value="Teknaf" label="TEKNAF">TEKNAF</option>
    <option value="Thakurgan" label="THAKURGAON">THAKURGAON</option>
    <option value="Dhaka" label="TONGI">TONGI</option>
    <option value="Foridpur" label="TUNGIPARA">TUNGIPARA</option>
    <option value="Dhaka" label="UTTARA">UTTARA</option> 
    <option value="Kushtia" label="VERAMARA">VERAMARA</option>
    <option value="Voirob" label="VOIROB">VOIROB</option>
</select><br/>
<label>Departing On</label><br />             
<input type="date" name="time" id="searchmenu_departingon" value="29/07/2017" maxlength="255" class="input-text" required/><br>                                

<label>Coach Type:</label><br />
<select name="type" required>
    <option value="" label="---" selected="selected">---</option>
    <option value="Ac" label="AC">AC</option>
    <option value="Nonac" label="Nonac">NonAc</option>
</select><br /><br />
 <button type="submit" name="submit">Search</button>

</form>
</div>
<div >
<div style="float: left;">
<h2>Dhaka Office</h2>
<ol>
<li>Gabtoli Counter, Dhaka. Phone-8011759</li><br />
<li>Technical Counter, Dhaka. Phone-9008475</li><br />
<li>Kallyanpur Counter, Dhaka. Phone-9008498</li><br />
<li>College Gate Counter, Shaymoli, Dhaka-, Phone-8123439</li><br />
<li>Kalabagan Counter, Dhaka. Phone-8119901</li><br />
<li>Malibagh Counter, Dhaka. Phone-8354748</li><br />
<li>Fakirapool Counter, Dhaka. Phone-01713-049557</li><br />
<li>Arambagh Counter, Dhaka. Phone-7102007</li><br />
<li>Shaydabad Counter, Dhaka. Phone-01713-049559</li><br />
<li>Janopath Counter, Dhaka. Phone-7554318</li><br />
<li>Uttara Counter, Dhaka. Phone-01711-974073</li><br />
<li>Nordda Office, Dhaka. Phone-01712-894932</li><br />
</ol>
</div>
<div style="max-width:500px;float: right;">
  <img class="mySlides" src="image/hanif bus 2.jpg" style="width:100%">
  <img class="mySlides"  src="image/image.png" style="width:100%">
  <img class="mySlides"  src="image/image1.png" style="width:100%">
  <img class="mySlides"  src="image/image2.jpg" style="width:100%">
  <img class="mySlides"  src="image/image3.jpg" style="width:100%">
  <img class="mySlides"  src="image/image1.png" style="width:100%">

<script>
var myIndex = 0;
carousel();

function carousel() {
    var i;
    var x = document.getElementsByClassName("mySlides");
    for (i = 0; i < x.length; i++) {
       x[i].style.display = "none";  
    }
    myIndex++;
    if (myIndex > x.length) {myIndex = 1}    
    x[myIndex-1].style.display = "block";  
    setTimeout(carousel, 2000); // Change image every 2 seconds
}
</script>
</div>
</div>
</div>
</body>
</html> 