<div id="header" bgcolor="#CCCCCC">
	<div id="content">
	
    <label>HANIF ENTERPRISE</label>
    </div>
</div>