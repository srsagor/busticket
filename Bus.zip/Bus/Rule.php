<!DOCTYPE html PUBLIC "-//W3C//DTD XHTML 1.0 Transitional//EN" "http://www.w3.org/TR/xhtml1/DTD/xhtml1-transitional.dtd">
<html xmlns="http://www.w3.org/1999/xhtml">
<head>
<meta http-equiv="Content-Type" content="text/html; charset=iso-8859-1" />
<title>Untitled Document</title>
</head>

<body>
<h2>bKash Payment Steps :</h2>
You can make payments from your bKash Account to our Merchant .
<ul>
<li> Go to your bKash Mobile Menu by dialing *247#</li>
<li> Choose Payment option by pressing 3</li>
<li> Enter the Merchant bKash Account Number 01727545460</li>
<li> Enter the fare  taka you want to pay.</li>
<li> Write the word tickets against your payment</li>
<li> Enter the Counter Number 0</li>
<li> Now enter your bKash Mobile Menu PIN to confirm</li>
</ul>
<p>Done! You will receive a confirmation message from bKash.</p>
<p>*If Reference or Counter No. or both are not applicable, you can skip them by entering 0.</p>
<p>*** Please wait 2 minutes..... Then try with your bKash Trx ID, otherwise you will see the "Access denied . Transation ID is not related to username" messsage.</p>
</body>
</html>
