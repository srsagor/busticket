<!DOCTYPE html PUBLIC "-//W3C//DTD XHTML 1.0 Transitional//EN" "http://www.w3.org/TR/xhtml1/DTD/xhtml1-transitional.dtd">
<html xmlns="http://www.w3.org/1999/xhtml">
<head>
<link rel="stylesheet" href="style.css">
<link rel="stylesheet" href="style1.css">
<meta http-equiv="Content-Type" content="text/html; charset=iso-8859-1" />
<title>User Page</title>
</head>

<body bgcolor="#CCCCCC">
<h1 align="center" >HANIF ENTERPRISE</h1>
<ul>
<li><a href="Cancel.php">Cancel Ticket</a></li>
                    <li><a href="final.php">Confirm Ticket</a></li>
					<li> <a href="Logout.php">Log out</a></li>
</ul>

</body>
</html>
