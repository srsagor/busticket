<div id="footer" bgcolor="#CCCCCC">
	<div id="content">
	
    <label>Hanif Enterprise</label>
    </div>
</div>