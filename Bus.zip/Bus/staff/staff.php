<html>
<head>
<title>Staff home</title>
</head>
<body bgcolor="#999999">
<h1 align="center" style="background-color:#00CCFF">HANIF ENTERPRICE</h1>
<a href="Logout.php"><img src="log.jpg"  height="42" width="42" align="middle"/></a>

<form target="" method="post" action="staff.php">
<label>Leave Form</label>
<select name="source" required >
    <option value="" label="---" selected="selected">---</option>
    <option value="Abullahpur" label="ABDULLAHPUR">ABDULLAHPUR</option>
    <option value="B-baria" label="B-BARIA">B-BARIA</option>
    <option value="Babuchar" label="BABUCHAR">BABUCHAR</option>
    <option value="Bagaihat" label="BAGAIHAT">BAGAIHAT</option>
    <option value="Bagerhat" label="BAGERHAT">BAGERHAT</option>
    <option value="Bandarban" label="BANDARBAN">BANDARBAN</option>
    <option value="Barguna" label="BARGUNA">BARGUNA</option>
    <option value="Barisal" label="BARISAL">BARISAL</option>
    <option value="Basurhat" label="BASURHAT">BASURHAT</option>
    <option value="Beanibazar" label="BEANIBAZAR">BEANIBAZAR</option>
    <option value="Benapole" label="BENAPOLE">BENAPOLE</option>
    <option value="Birampur" label="BIRAMPUR">BIRAMPUR</option>
    <option value="Bogra" label="BOGRA">BOGRA</option>
    <option value="Bonpara" label="BONPARA">BONPARA</option>
    <option value="Chandpur" label="CHANDPUR">CHANDPUR</option>
    <option value="Dhaka" label="CHANDRA">CHANDRA</option>
    <option value="Rajshahi" label="CHAPAINABABGANJ">CHAPAINABABGANJ</option>
    <option value="Chittagong" label="CHITTAGONG">CHITTAGONG</option>
    <option value="Comilla" label="COMILLA">COMILLA</option>
    <option value="Cox's bazar" label="COX'S BAZAR">COX'S BAZAR</option>
    <option value="Dhaka" label="DHAKA">DHAKA</option>
    <option value="Dinajpur" label="DINAJPUR">DINAJPUR</option>
    <option value="Kushtia" label="DORSHONA">DORSHONA</option>
    <option value="Faridpur" label="FARIDPUR">FARIDPUR</option>
    <option value="Feni" label="FENI">FENI</option>
    <option value="Fulbari" label="FULBARI">FULBARI</option>
    <option value="Gaibandha" label="GAIBANDHA">GAIBANDHA</option>
    <option value="Dhaka" label="GAZIPUR">GAZIPUR</option>
    <option value="Rajshahi" label="GODAGARI">GODAGARI</option>
    <option value="Faridpur" label="GOPALGANJ">GOPALGANJ</option>   
    <option value="Dinajpur" label="HILI">HILI</option>
    <option value="Bogura" label="JAIPURHAT">JAIPURHAT</option>
    <option value="Jessore" label="JESSORE">JESSORE</option>
    <option value="Jhenaidha" label="JHENAIDAH">JHENAIDAH</option>
    <option value="Jhenaidha" label="KALIGANJ">KALIGANJ</option>
    <option value="Rajshahi" label="KANSAT">KANSAT</option>
    <option value="Khagrachari" label="KHAGRACHARI">KHAGRACHARI</option>
    <option value="Khulna" label="KHULNA">KHULNA</option>
    <option value="Kuakata" label="KUAKATA">KUAKATA</option>
    <option value="Kurigram" label="KURIGRAM">KURIGRAM</option>
    <option value="Kushtia" label="KUSHTIA">KUSHTIA</option>
    <option value="Lakhipur" label="LAKHIPUR">LAKHIPUR</option>
    <option value="Lalmonirhat" label="LALMONIRHAT">LALMONIRHAT</option>
    <option value="Magura" label="MAGURA">MAGURA</option>
    <option value="Dhaka" label="MALIBAG">MALIBAG</option>
    <option value="Manikganj" label="MANIKGANJ">MANIKGANJ</option>
    <option value="Meherpur" label="MEHERPUR">MEHERPUR</option>
    <option value="Dhaka" label="MOHAKHALI">MOHAKHALI</option>
    <option value="Sylhet" label="MOULVIBAZAR">MOULVIBAZAR</option>
    <option value="Mymensing" label="MYMENSINGH">MYMENSINGH</option>
    <option value="Naogan" label="NAOGAON">NAOGAON</option>
    <option value="Narayanganj" label="NARAYANGANJ">NARAYANGANJ</option>
    <option value="Rajshahi" label="NATORE">NATORE</option>
    <option value="Noakhali" label="NOAKHALI">NOAKHALI</option>
    <option value="Narayanganj" label="NORDA">NORDA</option>
    <option value="Kushtia" label="PABNA">PABNA</option>
    <option value="Kushtia" label="PAKSHI">PAKSHI</option>
    <option value="Pirojpur" label="PIROJPUR">PIROJPUR</option>
    <option value="Rajshahi" label="PUTHIA">PUTHIA</option>
    <option value="Rajshahi" label="RAHANPUR">RAHANPUR</option>
    <option value="Faridpur" label="RAJABARI">RAJABARI</option>
    <option value="Rajshahi" label="RAJSHAHI">RAJSHAHI</option>
    <option value="Rangamati" label="RANGAMATI">RANGAMATI</option>
    <option value="Rangpur" label="RANGPUR">RANGPUR</option>
    <option value="Kushtia" label="RUPPUR">RUPPUR</option>
    <option value="Khulna" label="SATKHIRA">SATKHIRA</option>
    <option value="Narayngang" label="SAYADABAD">SAYADABAD</option>
    <option value="Dhaka" label="SHAHJADPUR">SHAHJADPUR</option>
    <option value="Sherpur" label="SHERPUR">SHERPUR</option>
    <option value="Sirajgonj" label="SIRAJGONJ">SIRAJGONJ</option>
    <option value="Syedpur" label="SYEDPUR">SYEDPUR</option>
    <option value="Sylhet" label="SYLHET">SYLHET</option>
    <option value="Tangail" label="TANGAIL">TANGAIL</option>
    <option value="Teknaf" label="TEKNAF">TEKNAF</option>
    <option value="Thakurgan" label="THAKURGAON">THAKURGAON</option>
    <option value="Dhaka" label="TONGI">TONGI</option>
    <option value="Foridpur" label="TUNGIPARA">TUNGIPARA</option>
    <option value="Dhaka" label="UTTARA">UTTARA</option> 
    <option value="Kushtia" label="VERAMARA">VERAMARA</option>
    <option value="Voirob" label="VOIROB">VOIROB</option>
</select>
<label>Going To</label>
<select name="desti" required>
    <option value="" label="---" selected="selected">---</option>
    <option value="Abullahpur" label="ABDULLAHPUR">ABDULLAHPUR</option>
    <option value="B-baria" label="B-BARIA">B-BARIA</option>
    <option value="Babuchar" label="BABUCHAR">BABUCHAR</option>
    <option value="Bagaihat" label="BAGAIHAT">BAGAIHAT</option>
    <option value="Bagerhat" label="BAGERHAT">BAGERHAT</option>
    <option value="Bandarban" label="BANDARBAN">BANDARBAN</option>
    <option value="Barguna" label="BARGUNA">BARGUNA</option>
    <option value="Barisal" label="BARISAL">BARISAL</option>
    <option value="Basurhat" label="BASURHAT">BASURHAT</option>
    <option value="Beanibazar" label="BEANIBAZAR">BEANIBAZAR</option>
    <option value="Benapole" label="BENAPOLE">BENAPOLE</option>
    <option value="Birampur" label="BIRAMPUR">BIRAMPUR</option>
    <option value="Bogra" label="BOGRA">BOGRA</option>
    <option value="Bonpara" label="BONPARA">BONPARA</option>
    <option value="Chandpur" label="CHANDPUR">CHANDPUR</option>
    <option value="Dhaka" label="CHANDRA">CHANDRA</option>
    <option value="Rajshahi" label="CHAPAINABABGANJ">CHAPAINABABGANJ</option>
    <option value="Chittagong" label="CHITTAGONG">CHITTAGONG</option>
    <option value="Comilla" label="COMILLA">COMILLA</option>
    <option value="Cox's bazar" label="COX'S BAZAR">COX'S BAZAR</option>
    <option value="Dhaka" label="DHAKA">DHAKA</option>
    <option value="Dinajpur" label="DINAJPUR">DINAJPUR</option>
    <option value="Kushtia" label="DORSHONA">DORSHONA</option>
    <option value="Faridpur" label="FARIDPUR">FARIDPUR</option>
    <option value="Feni" label="FENI">FENI</option>
    <option value="Fulbari" label="FULBARI">FULBARI</option>
    <option value="Gaibandha" label="GAIBANDHA">GAIBANDHA</option>
    <option value="Dhaka" label="GAZIPUR">GAZIPUR</option>
    <option value="Rajshahi" label="GODAGARI">GODAGARI</option>
    <option value="Faridpur" label="GOPALGANJ">GOPALGANJ</option>   
    <option value="Dinajpur" label="HILI">HILI</option>
    <option value="Bogura" label="JAIPURHAT">JAIPURHAT</option>
    <option value="Jessore" label="JESSORE">JESSORE</option>
    <option value="Jhenaidha" label="JHENAIDAH">JHENAIDAH</option>
    <option value="Jhenaidha" label="KALIGANJ">KALIGANJ</option>
    <option value="Rajshahi" label="KANSAT">KANSAT</option>
    <option value="Khagrachari" label="KHAGRACHARI">KHAGRACHARI</option>
    <option value="Khulna" label="KHULNA">KHULNA</option>
    <option value="Kuakata" label="KUAKATA">KUAKATA</option>
    <option value="Kurigram" label="KURIGRAM">KURIGRAM</option>
    <option value="Kushtia" label="KUSHTIA">KUSHTIA</option>
    <option value="Lakhipur" label="LAKHIPUR">LAKHIPUR</option>
    <option value="Lalmonirhat" label="LALMONIRHAT">LALMONIRHAT</option>
    <option value="Magura" label="MAGURA">MAGURA</option>
    <option value="Dhaka" label="MALIBAG">MALIBAG</option>
    <option value="Manikganj" label="MANIKGANJ">MANIKGANJ</option>
    <option value="Meherpur" label="MEHERPUR">MEHERPUR</option>
    <option value="Dhaka" label="MOHAKHALI">MOHAKHALI</option>
    <option value="Sylhet" label="MOULVIBAZAR">MOULVIBAZAR</option>
    <option value="Mymensing" label="MYMENSINGH">MYMENSINGH</option>
    <option value="Naogan" label="NAOGAON">NAOGAON</option>
    <option value="Narayanganj" label="NARAYANGANJ">NARAYANGANJ</option>
    <option value="Rajshahi" label="NATORE">NATORE</option>
    <option value="Noakhali" label="NOAKHALI">NOAKHALI</option>
    <option value="Narayanganj" label="NORDA">NORDA</option>
    <option value="Kushtia" label="PABNA">PABNA</option>
    <option value="Kushtia" label="PAKSHI">PAKSHI</option>
    <option value="Pirojpur" label="PIROJPUR">PIROJPUR</option>
    <option value="Rajshahi" label="PUTHIA">PUTHIA</option>
    <option value="Rajshahi" label="RAHANPUR">RAHANPUR</option>
    <option value="Faridpur" label="RAJABARI">RAJABARI</option>
    <option value="Rajshahi" label="RAJSHAHI">RAJSHAHI</option>
    <option value="Rangamati" label="RANGAMATI">RANGAMATI</option>
    <option value="Rangpur" label="RANGPUR">RANGPUR</option>
    <option value="Kushtia" label="RUPPUR">RUPPUR</option>
    <option value="Khulna" label="SATKHIRA">SATKHIRA</option>
    <option value="Narayngang" label="SAYADABAD">SAYADABAD</option>
    <option value="Dhaka" label="SHAHJADPUR">SHAHJADPUR</option>
    <option value="Sherpur" label="SHERPUR">SHERPUR</option>
    <option value="Sirajgonj" label="SIRAJGONJ">SIRAJGONJ</option>
    <option value="Syedpur" label="SYEDPUR">SYEDPUR</option>
    <option value="Sylhet" label="SYLHET">SYLHET</option>
    <option value="Tangail" label="TANGAIL">TANGAIL</option>
    <option value="Teknaf" label="TEKNAF">TEKNAF</option>
    <option value="Thakurgan" label="THAKURGAON">THAKURGAON</option>
    <option value="Dhaka" label="TONGI">TONGI</option>
    <option value="Foridpur" label="TUNGIPARA">TUNGIPARA</option>
    <option value="Dhaka" label="UTTARA">UTTARA</option> 
    <option value="Kushtia" label="VERAMARA">VERAMARA</option>
    <option value="Voirob" label="VOIROB">VOIROB</option>
</select>
<label>Departing On</label>            
<input type="date" name="time" id="searchmenu_departingon" value="29/07/2017" maxlength="255" class="input-text" required/>                                

<label>Coach Type:</label>
<select name="type" required>
    <option value="" label="---" selected="selected">---</option>
    <option value="Ac" label="AC">AC</option>
    <option value="Nonac" label="Nonac">NonAc</option>
</select>
 <button type="submit" name="submit">Search</button>

</form>
</body>
</html>
<?php
include("Config.php");
 //session_start();
if($_SERVER["REQUEST_METHOD"] == "POST") { 
      $s = mysqli_real_escape_string($db,$_POST['source']);
      $d = mysqli_real_escape_string($db,$_POST['desti']); 
	  $da = mysqli_real_escape_string($db,$_POST['time']);
      $t = mysqli_real_escape_string($db,$_POST['type']);
	   
$sql = "SELECT * FROM  businfo WHERE source='$s' and Dest='$d' and Date='$da'and Type='$t'";
$result = $db->query($sql);

echo "<table border='1'width='100%'>
<tr>
<th>Source</th>
<th>Dest</th>
<th>Date</th>
<th>Time</th>
<th>TYPE</th>
<th>Seat availe</th>
<th>Bus no</th>
<th>Price</th>
</tr>";

while($row = mysqli_fetch_array($result))
{
echo "<tr>";
echo "<td>" . $row['source'] . "</td>";
echo "<td>" . $row['Dest'] . "</td>";
echo "<td>" . $row['Date'] . "</td>";
echo "<td>" . $row['Time'] . "</td>";
echo "<td>" . $row['Type'] . "</td>";
echo "<td>" . $row['Avile'] . "</td>";
echo "<td>" . $row['BusNo'] . "</td>";
echo "<td>" . $row['price'] . "</td>";
echo '<form method="post" action="../sagor1.php">
                <input type="hidden" name="source" value='.$row['source'].'>
				<input type="hidden" name="desti" value='.$row['Dest'].'>
				<input type="hidden" name="date" value='.$row['Date'].'>
				<input type="hidden" name="busno" value='.$row['BusNo'].'>
                <input type="hidden" name="type" value='.$row['Type'].'>
				<input type="hidden" name="time1" value='.$row['Time'].'>
				<input type="hidden" name="price" value='.$row['price'].'>
                <td><input type="submit" name="accept" value="View Seat" ></td>';   
                echo "</form>";

echo "</tr>";
}
echo "</table>";
}

?>
